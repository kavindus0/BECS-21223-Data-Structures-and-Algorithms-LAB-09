package Question01;

public class MainApp {
    public static void main(String[] args) {
        List productList = new List(10);
        productList.add(new Product("P108", "Wireless Mouse", "Electronics", 2160, 30));
        productList.add(new Product("P034", "Handbag", "Accessories", 3450, 5));
        productList.add(new Product("P078", "Phone cover", "Accessories", 1750, 26));
        productList.add(new Product("P105", "Bluetooth Speaker", "Electronics", 13780, 5));
        productList.add(new Product("P003", "Ladies blouse", "Clothing", 1650, 18));
        productList.add(new Product("P053", "Shampoo", "Groceries", 2370, 20));
        productList.add(new Product("P114", "Laptop", "Electronics", 250000, 3));
        productList.add(new Product("P004", "Frock", "Clothing", 4520, 10));
        productList.add(new Product("P117", "Earphone", "Electronics", 7860, 2));
        productList.add(new Product("P120", "Microwave oven", "Electronics", 56830, 1));

        System.out.println("Sales amount of each product on last Friday");
        for (int i = 0; i < 10; i++) {
            System.out.print(productList.productList[i].ProductID+"\t");
            System.out.println(productList.productList[i].getQuantitySoldOnFriday()*productList.productList[i].getUnitPrice());
        }

        System.out.println("Sort the sales details according to the sales amount of each product using\n" +
                "selection sort and display them");

        for (int i = 0; i <productList.size-1; i++) {
            int min0 = i;
            for (int j = i+1; j < productList.size ; j++) {
                if (productList.productList[j].QuantitySoldOnFriday<productList.productList[min0].QuantitySoldOnFriday)
                        min0 = j;
            }

            Product temp = productList.productList[min0];
            productList.productList[i] = productList.productList[min0];
            productList.productList[min0] = temp;

        }


    }
}


