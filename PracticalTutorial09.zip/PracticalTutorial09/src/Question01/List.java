package Question01;

public class List {
    public Product[] productList;
    int size;
    int capacity;

    public List(int capacity) {
        this.capacity = capacity;
        productList = new Product[capacity];
        size = 0;
    }

    void add(Product product){
        if (this.size<this.capacity) {
            productList[this.size++] = product;
            System.out.println("Successfully added "+ product.toString());
        } else {
            System.out.println("List Full");
        }
    }
}
