package Question01;

public class Product {
    public String ProductID;
    public String ProductName;
    public String Category;
    public double UnitPrice;
    public int QuantitySoldOnFriday;

    @Override
    public String toString() {
        return "Product{" +
                "ProductID='" + ProductID + '\'' +
                ", ProductName='" + ProductName + '\'' +
                ", Category='" + Category + '\'' +
                ", UnitPrice=" + UnitPrice +
                ", QuantitySoldOnFriday=" + QuantitySoldOnFriday +
                '}';
    }

    public Product(String productID, String productName, String category, double unitPrice, int quantitySoldOnFriday) {
        ProductID = productID;
        ProductName = productName;
        Category = category;
        UnitPrice = unitPrice;
        QuantitySoldOnFriday = quantitySoldOnFriday;
    }

    public double getUnitPrice() {
        return UnitPrice;
    }

    public int getQuantitySoldOnFriday() {
        return QuantitySoldOnFriday;
    }
}
